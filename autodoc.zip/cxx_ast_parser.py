# cxx_ast_parser.py

import sys
import os
from clang import cindex
from typing import List, Tuple

# Definition = (тип, имя, номер строки)
Definition = Tuple[str, str, int]

def parse_file(path: str, clang_args: List[str] = None) -> cindex.TranslationUnit:
    if clang_args is None:
        clang_args = ['-std=c++17', '-I.']
    index = cindex.Index.create()
    tu = index.parse(path, args=clang_args)
    return tu

def extract_definitions(tu: cindex.TranslationUnit) -> List[Definition]:
    defs: List[Definition] = []
    source_file = os.path.abspath(tu.spelling)

    def visitor(cursor):
        loc = cursor.location
        if not loc.file or os.path.abspath(loc.file.name) != source_file:
            return

        kind = cursor.kind
        if kind == cindex.CursorKind.FUNCTION_DECL:
            defs.append(("function", cursor.spelling, loc.line))
        elif kind in (cindex.CursorKind.CLASS_DECL, cindex.CursorKind.STRUCT_DECL):
            defs.append(("class", cursor.spelling, loc.line))
        elif kind == cindex.CursorKind.CXX_METHOD:
            parent = cursor.semantic_parent
            if parent.kind in (cindex.CursorKind.CLASS_DECL, cindex.CursorKind.STRUCT_DECL):
                defs.append(("method", f"{parent.spelling}::{cursor.spelling}", loc.line))

        for c in cursor.get_children():
            visitor(c)

    visitor(tu.cursor)
    return defs

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python cxx_ast_parser.py path/to/file.cpp")
        sys.exit(1)
    tu = parse_file(sys.argv[1])
    for t, name, line in extract_definitions(tu):
        print(f"{t.title():<8} {name:<30} (line {line})")
