# cxx_ast_parser.py

import sys
import os
from clang import cindex
from typing import List, Tuple

# Кортеж: (тип, имя, номер строки)
Definition = Tuple[str, str, int]

def parse_file(path: str, clang_args: List[str] = None) -> cindex.TranslationUnit:
    """
    Парсит C++-файл и возвращает TranslationUnit.
    clang_args позволяет указать include-пути и стандарты.
    """
    if clang_args is None:
        clang_args = ['-std=c++17', '-I.']
    index = cindex.Index.create()
    tu = index.parse(path, args=clang_args)
    return tu

def extract_definitions(tu: cindex.TranslationUnit) -> List[Definition]:
    """
    Из TranslationUnit извлекает определения:
      - свободные функции (FUNCTION_DECL)
      - классы и структуры (CLASS_DECL, STRUCT_DECL)
      - методы внутри классов/структур (CXX_METHOD)
    """
    defs: List[Definition] = []
    source_file = os.path.abspath(tu.spelling)

    def visitor(cursor):
        # Отбираем только узлы из того же файла, что и исходник
        loc = cursor.location
        if not loc.file or os.path.abspath(loc.file.name) != source_file:
            return

        kind = cursor.kind
        if kind == cindex.CursorKind.FUNCTION_DECL:
            defs.append(("function", cursor.spelling, loc.line))
        elif kind in (cindex.CursorKind.CLASS_DECL, cindex.CursorKind.STRUCT_DECL):
            # Определение класса/структуры
            defs.append(("class", cursor.spelling, loc.line))
        elif kind == cindex.CursorKind.CXX_METHOD:
            parent = cursor.semantic_parent
            # Только методы внутри классов/структур
            if parent.kind in (cindex.CursorKind.CLASS_DECL, cindex.CursorKind.STRUCT_DECL):
                defs.append(("method", f"{parent.spelling}::{cursor.spelling}", loc.line))

        # Рекурсивно обходим детей
        for c in cursor.get_children():
            visitor(c)

    visitor(tu.cursor)
    return defs

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python cxx_ast_parser.py path/to/file.cpp")
        sys.exit(1)

    file_path = sys.argv[1]
    tu = parse_file(file_path)
    definitions = extract_definitions(tu)
    for t, name, line in definitions:
        print(f"{t.title():<8} {name:<30} (line {line})")
